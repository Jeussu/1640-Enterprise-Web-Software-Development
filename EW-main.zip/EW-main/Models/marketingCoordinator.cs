﻿namespace WebApplication1.Models
{
    public class marketingCoordinator
    {
        public string marketingCoordinatorEmail { get; set; }

        public string marketingCoordinatorId { get; set; }
        public string marketingCoordinatorPhone { get; set; }
    }
}