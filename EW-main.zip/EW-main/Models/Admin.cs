﻿namespace WebApplication1.Models
{
    public class Admin
    {

        public string adminEmail { get; set; }

        public string adminPhone { get; set; }
    }
}