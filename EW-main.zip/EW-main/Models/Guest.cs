﻿namespace WebApplication1.Models
{
    public class Guest
    {
        public string guestEmail { get; set; }

        public string guestPhone { get; set; }
    }
}