﻿namespace WebApplication1.Models
{
    public class marketingManager
    {
        public string marketingManagerEmail { get; set; }

        public string marketingManagerId { get; set; }

        public string marketingManagerPhone { get; set; }
    }
}