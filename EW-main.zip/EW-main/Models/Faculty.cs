﻿namespace WebApplication1.Models
{
    public class Faculty
    {

        public SignUpModel marketingCoordinatorId { get; set; }

        public SignUpModel[] Student { get; set; }

    }
}