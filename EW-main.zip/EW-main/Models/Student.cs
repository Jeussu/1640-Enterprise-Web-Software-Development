﻿namespace WebApplication1.Models
{
    public class Student
    {
        public string studentEmail { get; set; }

        public string student { get; set; }

        public string studentPhone { get; set; }
    }
}